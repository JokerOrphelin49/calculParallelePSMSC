#ifndef EXO_1_H
#define EXO_1_H
void p2p_transmit_A(int p, int q, Matrix *A, int i, int l);
void p2p_transmit_B(int p, int q, Matrix *B, int l, int j);
#endif
