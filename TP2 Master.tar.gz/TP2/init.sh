#!/bin/bash
SIMGRID=/mnt/n7fs/ens/tp_guivarch/opt2023/simgrid-3.32

export PATH=${SIMGRID}/bin:${PATH}
